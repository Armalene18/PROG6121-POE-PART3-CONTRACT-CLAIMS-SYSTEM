﻿using System;
using System.Collections.Generic;
using System.IO;

namespace ClaimSystem
{
    /// <summary>
    /// Represents a document attached to a claim (e.g., proof of hours, contracts).
    /// </summary>
    public class Document
    {
        public string FileName { get; set; } = string.Empty;
        public string FilePath { get; set; } = string.Empty;

        /// <summary>
        /// File type detection (PDF, Image, DOCX, XLSX).
        /// </summary>
        public string FileType
        {
            get
            {
                string extension = Path.GetExtension(FileName);
                return string.IsNullOrWhiteSpace(extension)
                    ? string.Empty
                    : extension.ToUpper();
            }
        }

        /// <summary>
        /// Date uploaded for auditing.
        /// </summary>
        public DateTime UploadedOn { get; set; } = DateTime.Now;
    }

    /// <summary>
    /// Represents a lecturer monthly claim within the Claim System.
    /// </summary>
    public class Claim
    {
        private static int _autoId = 1;

        /// <summary>
        /// Unique ID for every claim.
        /// </summary>
        public int Id { get; private set; }

        public string LecturerName { get; set; } = string.Empty;
        public int HoursWorked { get; set; }
        public decimal HourlyRate { get; set; }
        public string Notes { get; set; } = string.Empty;

        /// <summary>
        /// Claim Status: Pending, Approved, Rejected, Sent to HR, Completed.
        /// </summary>
        public string Status { get; set; } = "Pending";

        /// <summary>
        /// Claim documents.
        /// </summary>
        public List<Document> Documents { get; set; } = new();

        /// <summary>
        /// The user who approved the claim.
        /// </summary>
        public string? ApprovedBy { get; set; }

        /// <summary>
        /// The user who rejected the claim.
        /// </summary>
        public string? RejectedBy { get; set; }

        /// <summary>
        /// Reason provided when rejecting the claim.
        /// </summary>
        public string? RejectionReason { get; set; }

        /// <summary>
        /// Timestamp when created.
        /// </summary>
        public DateTime CreatedOn { get; private set; }

        /// <summary>
        /// Timestamp when modified.
        /// </summary>
        public DateTime LastUpdated { get; private set; }

        public override bool Equals(object? obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string? ToString()
        {
            return base.ToString();
        }
    }

        /// <summary>
        /// Calculates
